#' Segmentation of an INAR(p) process by Penalized Maximum Likelihood
#'
#' @param Y is a sequence of data of size n x 1. Note: NA in the data are allowed.
#' @param p is the order of the INAR(p). Default value is 2.
#' @param lmin is the minimum length of the segments. Default value is 7.
#' @param Kmax is the maximal number of segments. Default value is 15.
#' @param selectionK specifies the penalty criterion used for the selection of the number of segments K.
#'   Options are: \code{"none"}, \code{"Lav"}, \code{"Cley"}, \code{"mBIC"}, \code{"Multiscale"}, or \code{"All"}). Default is \code{"Lav"}.
#'   If \code{selectionK = "none"}, the function returns the best segmentation into \code{K = Kmax} segments.
#'   If \code{selectionK = "All"}, the results for all three criteria are given.
#' @param tol is the tolerance for stopping the EM algorithm. The algorithm stops when changes in parameter estimates fall below this value. Default is 1e-3
#' @param maxIter is the maximum number of iterations of the EM algorithm used to estimate the parameters of the INAR(p) model. Default is 1000
#'
#' @return
#' \itemize{
#' \item \code{Tmu} is a data frame containing the segmentation results, with p+3 columns and a number of lines equal to the number of segments.
#'   The columns are: \code{$begin, $end, $alpha1, ..., $alphap, $lambda}.
#' \item \code{Contrast} is the contrast function, that is the minus log-likelihood, for the fit for all K=1,...,Kmax.
#' \item \code{Crit} is the criterion (the penalized contrast) calculated for the estimated segmentation.
#' }
#' If \code{selectionK="All"}, the outputs \code{Tmu} and \code{Crit} are lists, containing the corresponding results obtained for each of the model selection criteria.
#'
#' @details
#' The parameter's distribution (the coefficients of the INAR(p), alpha, and lambda, the parameter of the distribution of the innovation) have been estimated using an EM algorithm. The number of segments is obtained by model selection using one of the following penalty criteria:
#'   \itemize{
#'   \item \code{Lav}, the penalty proposed Lavielle (2005),
#'   \item \code{Cley}, the penalty developed by Cleynen and Lebarbier (2017) based on the works of Birge and Massart (2001). The penalty constant is calibrated using the slope heuristic (see Arlot and Massart (2009)),
#'   \item \code{mBIC}, the modified BIC critetion proposed by Siegmund and Zhang (2007)
#'   \item \code{multiscale}, the penalty proposed by Verzelen et al. (2023).
#'   }
#'
#' Note: by convention, the position of a change-point refers to the last point in a segment (\code{Tmu$end}).
#'
#' @importFrom grDevices chull
#' @importFrom stats acf dbinom dpois optim
#' @importFrom dplyr %>% first
#' @export
SegINARp <- function(Y,p=2,lmin=7,Kmax=15,selectionK="Lav", tol=1e-3,maxIter=1000){
  result  <-  list()
  Y.withoutNA  <-  c()

  cond1 <- TRUE
  cond2 <- TRUE
  cond3 <- TRUE
  cond4 <- TRUE
  cond5 <- TRUE


  #Parameters
  S     <- 0.75

  #For NA
  present.data  <- which(!is.na(Y))
  n.Y           <- length(Y)
  if (length(present.data)<n.Y) {
    Y.withoutNA<- Y[present.data]
    n.Y.withoutNA <- length(Y.withoutNA)
    Ind.NA <- "Yes"
  } else {
    Y.withoutNA<- Y
    n.Y.withoutNA <- n.Y
    Ind.NA <- "No"
  }
  Kseq <- 1:Kmax


  #The conditions to be fulfilled
  if (Kmax >n.Y.withoutNA) {
    cond1 <- FALSE
    warning("The maximal number of segments Kmax ", Kmax," needs to be lower than the length of the data " ,n.Y.withoutNA,"\n")
  }

  if(lmin > round(n.Y.withoutNA/Kmax)){
    cond2 <- FALSE
    warning("The minimal length of the segments lmin", lmin," needs to be lower than " ,round(n.Y/Kmax),"\n")
  }

  if(lmin < p){
    cond3 <- FALSE
    warning("The minimal length of the segments lmin", lmin," needs to be greater than the order of the INAR" ,p,"\n")
  }

  if(Kmax==1){
    cond4 <- FALSE
    warning("Kmax=1 means no segmentation")
  }

  diff.Y <- diff(Y.withoutNA)
  runs <- rle(diff.Y == 0)
  max_zeros <- max(runs$lengths[runs$values])
  if (lmin <=max_zeros) {
    cond5 <- FALSE
    warning("The minimal length of the segments lmin", lmin," needs to be greater than the maximal number of same consecutive value in the data" ,max_zeros,"\n")
    }

  if ((cond1==TRUE) & (cond2==TRUE) & (cond3==TRUE) & (cond4==TRUE) & (cond5==TRUE)){

    #Used function for NA
    add_NA <- function(Tmu,present.data,Y.withoutNA){
      Tmu$begin  <- present.data[Tmu$begin]
      Tmu$end    <- present.data[Tmu$end]
      Tmu$end[length(Tmu$end)]  <- n.Y
      return(Tmu)
    }

    matD <- Gsegmentation_INAR(Y.withoutNA, lmin, p,tol,maxIter)
    SegResPenK <- DynProg(matD,Kmax)
    Contrast  <- SegResPenK$J.est

    if (selectionK=="none"){
      Kest <- Kmax
      seg <- SegResPenK$t.est[Kest,1:Kest]
      Tmu <- FormatOptSegK_INAR(seg,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu <- add_NA(Tmu, present.data, Y.withoutNA)
      }
      Crit <- Contrast[Kmax]
    }

    if (selectionK=="Lav"){
      ResModSel <- MLcriterion(Contrast, Kseq,S)
      Kest  <- ResModSel$Kh
      Crit <- ResModSel$Crit
      seg <- SegResPenK$t.est[Kest,1:Kest]
      Tmu <- FormatOptSegK_INAR(seg,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu <- add_NA(Tmu, present.data, Y.withoutNA)
        }
      }

    if (selectionK=="Cley"){
      pen.exp <- Kseq*((1+4*sqrt(1.1+log(n.Y.withoutNA/Kseq)))^2)
      ResModSel <- BMcriterion(Contrast,pen.exp)
      Kest  <- ResModSel$Kh
      Crit <- ResModSel$Crit
      seg <- SegResPenK$t.est[Kest,1:Kest]
      Tmu <- FormatOptSegK_INAR(seg,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu <- add_NA(Tmu, present.data, Y.withoutNA)
      }
    }

    if (selectionK=="mBIC"){
      LogLg <- c()
      LogLg <- apply(SegResPenK$t.est,1,FUN=function(z) sum(log(diff(c(0,z))[diff(c(0,z))>0])))
      ResModSel <- mBICcriterion(Contrast,LogLg,n.Y.withoutNA,Kseq)
      Kest  <- ResModSel$Kh
      seg <- SegResPenK$t.est[Kest,1:Kest]
      Tmu <- FormatOptSegK_INAR(seg,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu <- add_NA(Tmu, present.data, Y.withoutNA)
      }
    }

    if (selectionK=="Multiscale"){
      gamma <- 9
      beta <- 2.25
      LogLong <- LogLongSeg(lmin,Y.withoutNA)
      matD_LogLong <- matrix(Inf, nrow(matD), ncol(matD))
      calculable <- !(is.infinite(matD) & is.infinite(LogLong))
      matD_LogLong[calculable] <- matD[calculable] - beta * LogLong[calculable]
      SegResPenMultiscale <- DynProg(matD_LogLong,Kmax)
      penK_Multiscale <- Kseq*(gamma+beta*log(n.Y.withoutNA))
      Kest <- which.min(SegResPenMultiscale$J.est+penK_Multiscale)
      Crit <- SegResPenMultiscale$J.est[Kest]+penK_Multiscale[Kest]
      seg <- SegResPenMultiscale$t.est[Kest,1:Kest]
      Tmu <- FormatOptSegK_INAR(seg,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu <- add_NA(Tmu, present.data, Y.withoutNA)
      }
    }

    if (selectionK=="All"){
      Tmu <- list()
      Kest <- list()
      Crit <- list()

      #1=Lav
      ResModSel <- MLcriterion(Contrast, Kseq,S)
      Kest$Lav  <- ResModSel$Kh
      Crit$Lav <- ResModSel$Crit
      seg.Lav <- SegResPenK$t.est[Kest$Lav,1:Kest$Lav]
      Tmu.tmp <- FormatOptSegK_INAR(seg.Lav,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu.tmp <- add_NA(Tmu.tmp, present.data, Y.withoutNA)
      }
      Tmu$Lav <- Tmu.tmp

      #2=Cley
      pen.exp <- Kseq*((1+4*sqrt(1.1+log(n.Y.withoutNA/Kseq)))^2)
      ResModSel <- BMcriterion(Contrast,pen.exp)
      Kest$Cley  <- ResModSel$Kh
      Crit$Cley <- ResModSel$Crit
      seg.Cley <- SegResPenK$t.est[Kest$Cley,1:Kest$Cley]
      Tmu.tmp <- FormatOptSegK_INAR(seg.Cley,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu.tmp <- add_NA(Tmu.tmp, present.data, Y.withoutNA)
      }
      Tmu$Cley <- Tmu.tmp

      #3=mBIC
      LogLg <- c()
      LogLg <- apply(SegResPenK$t.est,1,FUN=function(z) sum(log(diff(c(0,z))[diff(c(0,z))>0])))
      ResModSel <- mBICcriterion(Contrast,LogLg,n.Y.withoutNA,Kseq)
      Kest$mBIC  <- ResModSel$Kh
      Crit$mBIC <- ResModSel$Crit
      seg.mBIC <- SegResPenK$t.est[Kest$mBIC,1:Kest$mBIC]
      Tmu.tmp <- FormatOptSegK_INAR(seg.mBIC,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu.tmp <- add_NA(Tmu.tmp, present.data, Y.withoutNA)
      }
      Tmu$mBIC <- Tmu.tmp

      #4=Multiscale
      gamma <- 9
      beta <- 2.25
      LogLong <- LogLongSeg(lmin,Y.withoutNA)
      matD_LogLong <- matrix(Inf, nrow(matD), ncol(matD))
      calculable <- !(is.infinite(matD) & is.infinite(LogLong))
      matD_LogLong[calculable] <- matD[calculable] - beta * LogLong[calculable]
      SegResPenMultiscale <- DynProg(matD_LogLong,Kmax)
      penK_Multiscale <- Kseq*(gamma+beta*log(n.Y.withoutNA))
      Kest$Multiscale <- which.min(SegResPenMultiscale$J.est+penK_Multiscale)
      Crit$Multiscale <- SegResPenMultiscale$J.est[Kest$Multiscale]+penK_Multiscale[Kest$Multiscale]
      seg.Multiscale <- SegResPenMultiscale$t.est[Kest$Multiscale,1:Kest$Multiscale]
      Tmu.tmp <- FormatOptSegK_INAR(seg.Multiscale,Y.withoutNA,p,tol,maxIter)
      if (Ind.NA=="Yes") {
        Tmu.tmp <- add_NA(Tmu.tmp, present.data, Y.withoutNA)
      }
      Tmu$Multiscale <- Tmu.tmp
    }

    result$Tmu <- Tmu
    result$Contrast <- Contrast
    result$Crit <- Crit
    return(result)
  }
}


######
# Used functions for segmentation

########
# Calculation of the Cost matrix
#########
Gsegmentation_INAR <- function(Y, lmin, p, tol, maxIter, progress = TRUE) {
  n <- length(Y)
  matD <- matrix(Inf, n, n)
  nl <- n - lmin + 1

  # séquences i et j
  i_seq <- unlist(lapply(1:nl, function(i) rep(i, n - i - lmin + 2)))
  j_seq <- unlist(lapply(1:nl, function(i) (i + lmin - 1):n))

  # barre de progression
  if (progress) pb <- utils::txtProgressBar(min = 0, max = length(i_seq), style = 3)

  calc_val <- function(idx) {
    i <- i_seq[idx]
    j <- j_seq[idx]
    Yij <- Y[i:j]
    param_init <- EM_init(Yij, p)
    res_EM <- EM_loop(Yij, p, param_init, tol, maxIter)
    val <- -res_EM$lv

    if (progress) utils::setTxtProgressBar(pb, idx)
    return(val)
  }

  # calcul des valeurs
  matD[cbind(i_seq, j_seq)] <- sapply(seq_along(i_seq), calc_val)

  if (progress) close(pb)
  invisible(matD)
}

# Gsegmentation_INAR <- function(Y, lmin, p,tol,int) {
#   n <- length(Y)
#   matD <- matrix(Inf, n, n)
#   nl <- n - lmin + 1
#
#   i_seq <- unlist(lapply(1:nl, function(i) rep(i, n - i - lmin + 2)))
#   j_seq <- unlist(lapply(1:nl, function(i) (i + lmin - 1):n))
#
#   calc_val <- function(i, j) {
#     Yij <- Y[i:j]
#     param_init <- EM_init(Yij, p)
#     res_EM <- EM_loop(Yij, p, param_init, tol, maxIter)
#     -res_EM$lv
#   }
#
#   matD[cbind(i_seq, j_seq)] <- mapply(calc_val, i_seq, j_seq)
#
#   invisible(matD)
# }


########
# Calculation of the log length of the segments (in a matrix with same dimension as matD)
#########
LogLongSeg <- function(lmin,Y) {
  n <- length(Y)
  LogLong <- matrix(Inf, n, n)
  nl <- n - lmin + 1

  i_seq <- unlist(lapply(1:nl, function(i) rep(i, n - i - lmin + 2)))
  j_seq <- unlist(lapply(1:nl, function(i) (i + lmin - 1):n))

  LogLong_val <- function(i, j) {log(j-i+1)}
  LogLong[cbind(i_seq, j_seq)] <- mapply(LogLong_val, i_seq, j_seq)
  invisible(LogLong)
}


#### Code of Dynamic Programming (matD is the cost matrix and Kmax is the maximal number of segments)
DynProg<-function(matD,Kmax)
{
  N<-dim(matD)[1]
  if (Kmax>N){cat("Kmax ", Kmax, "is greater than N ",N,"\n")
    cat("Kmax is supposed to be equal to N :", N,"\n")
    Kmax <- 13
  }

  I<-matrix(Inf,Kmax,N)
  t<-matrix(0,Kmax,N)
  I[1,]=matD[1,]
  matD=t(matD)


  if (Kmax>2)
  {

    for (k in 2:(Kmax-1))

      for (L in k:N)
      {
        I[k,L]<-min(I[(k-1),1:(L-1)]+matD[L,2:L])
        if(I[k,L]!=Inf)
          t[k-1,L]<-which.min(I[(k-1),1:L-1]+matD[L,2:L])
      }


  }

  I[Kmax,N]<-min(I[Kmax-1,1:(N-1)]+matD[N,2:N])
  if(I[Kmax,N]!=Inf)
    t[Kmax-1,N]<-which.min(I[(Kmax-1),1:N-1]+matD[N,2:N])

  # *** Calcul des instants de ruptures ***

  t.est<-matrix(0,Kmax,Kmax)
  diag(t.est)<-N
  for (K in 2:Kmax)
    for (k in seq(K-1,1,by=-1))
    {
      if(t.est[K,k+1]!=0)
        t.est[K,k]<-t[k,t.est[K,k+1]]
    }
  list(J.est = I[,N],t.est = t.est)
  #cat("Kmax", Kmax,"\n")
}


#### Model selection criteria
# ML
MLcriterion<-function(J,Kseq,S=0.75)
{
  Kmax=length(Kseq)
  Jtild=(J[Kmax]-J)/(J[Kmax]-J[1])*(Kseq[Kmax]-Kseq[1])+1
  D=diff(diff(Jtild))

  if (length(which(D>=S))>0){
    Kh <- max(which(D>=S))+1
  }else {
    Kh <- 1
  }
  Kh=Kseq[Kh]

  #find the constant
  kv <- chull(Kseq, J)
  rg_kv <- which(diff(kv)>0)
  if (length(rg_kv) > 0) {
    kv <- kv[-(rg_kv+1)]
  }
  pv <- -diff(J[kv])/diff(Kseq[kv])
  rg <- which(pv < 0)
  if (length(rg) > 0) {
    pv <- pv[-rg]
    kv <- kv[-rg]
  }
  pv <- rev(pv)
  kv <- rev(kv)
  beta_opt <- pv[which(kv==Kh)]
  Crit <- J[Kh]+beta_opt*Kh

  return(list(Kh=Kh,Crit=Crit))
}

## Slope heuristic
BMcriterion<-function(J,pen)
{
  Kmax=length(J)
  Kseq=1:Kmax
  kv <- chull(pen, J)
  rg_kv <- which(diff(kv)>0)
  if (length(rg_kv) > 0) {
    kv <- kv[-(rg_kv+1)]
  }
  pv <- -diff(J[kv])/diff(pen[kv])
  rg <- which(pv < 0)
  if (length(rg) > 0) {
    pv <- pv[-rg]
    kv <- kv[-rg]
  }
  pv <- rev(pv)
  kv <- rev(kv)
  if (length(pv) == 1) {
    stop("Error: the contrast function is not decreasing")
  }
  dv <- diff(kv)
  dmax <- max(dv)
  rt <- which.max(dv)
  alpha <- pv[rt]
  alpha_opt <- 2 * alpha
  km <- kv[alpha_opt >= pv] %>% first()
  Kh =Kseq[km]
  Crit <- J[Kh]+alpha_opt*pen[Kh]
  return(list(Kh=Kh,Crit=Crit))
}

##
mBICcriterion <- function(J,LogLg,n,Kseq){
  Kh=c()
  mBIC=c()
  mBIC=((n-Kseq)/2+1)*(-2*J/n+1+log(2*pi)-log(n))-(1/2)*LogLg-(Kseq-1)*log(n)+ lgamma((n-Kseq)/2+1)
  Kh=which.max(mBIC)
  Kh=Kseq[Kh]
  Crit <- mBIC[Kh]
  return(list(Kh=Kh,Crit=Crit))
}



##
FormatOptSegK_INAR <- function(seg,Y,p,tol,maxIter){
  K     = length(seg)
  rupt  = matrix(Inf,ncol = 2 , nrow= K)
  bp    = seg
  rupt[,2]  = bp
  bp        = bp +1
  rupt[,1]  = c(1, bp[1:K-1])

  param_list <- lapply(1:nrow(rupt), function(i) {
    z <- rupt[i, ]
    Yij <- Y[z[1]:z[2]]
    param_init <- EM_init(Yij, p)
    res_EM <- EM_loop(Yij, p, param_init, tol, maxIter)
    res_EM$param
  })

  param.seg <- do.call(rbind, lapply(param_list, function(x) {
    c(x$alpha, x$lambda)
  }))

  Tmu=as.data.frame(cbind(rupt,param.seg))
  colnames(Tmu)=c("begin","end",paste0("alpha", 1:p),"lambda")
  return(Tmu)
}



########
# Used function for EM


#############
###### Initialisation of the EM
EM_init <- function(Y,p){
  alpha <- c();beta <- c();lambda <- c()
  initial <-  YW(Y,p)
  alpha <- initial$alpha
  lambda <- initial$lambda
  param_init <- list(alpha=alpha,lambda=lambda)
  return(param_init)
}

#############
YW <- function(Y,p)
{
  # autocorrelation matrix
  R <- matrix(NA,p,p)
  r0 <- acf(Y,plot=F)$acf[1:(p+1)]
  r <- r0[2:(p+1)]
  R <- matrix(r0[abs(row(R) - col(R)) + 1],ncol=p)

  ################### estimation of alpha
  alpha <- c()
  alpha <- as.vector(solve(R)%*%r)
  alpha[alpha <= 0] <- 0.01
  alpha <- if (sum(alpha) >= 1) 0.99 * alpha / sum(alpha) else alpha

  ################### estimation of the parameteres of the innovation.
  lambda <- c()
  lambda <- mean(Y)*(1-sum(alpha))
  param <- c()
  param$alpha <- alpha
  param$lambda <- lambda
  return(param)
}


#############
###### Loop of the EM

EM_loop <- function(Y,p,param_init,tol=1e-3,maxIter=1000){

  n=length(Y)
  param <- param_init
  alpha <- param$alpha
  lambda <- param$lambda

  if (p > 1) {
    denom <- 1 - sum(alpha)
    beta <- alpha / (denom + alpha)
  }


  Iter <-  0
  Diff  <-  2*tol


  # E-M
  while ((Diff  > tol) & (Iter < maxIter))
  {
    Iter <-  Iter +1

    Aux <- loglike(Y,p,param)
    p_t <-  Aux$p_t

    #################################################################
    ############################ E STEP #############################
    #################################################################

    ############## latent st and btst
    st=btst=matrix(NA,nrow=n-p,ncol=p)

    #   for(j in 1:p)
    #    {
    #      fst_p=lapply((p+1):n,function(t) fst_propto(y,t,j,param))
    #      fbtst_p=lapply((p+1):n,function(t) fbtst_propto(y,t,j,param))
    #      st[,j]=sapply(fst_p,expectation)/p_t
    #      btst[,j]=sapply(fbtst_p,expectation)/p_t
    #    }

    st   <- sapply(1:p, function(j) {
      fst_p <- lapply((p+1):n, function(t) fst_propto(Y, t, j, param))
      sapply(fst_p, expectation) / p_t
    })

    # btst <- sapply(1:p, function(j) {
    #    fbtst_p <- lapply((p+1):n, function(t) fbtst_propto(y, t, j, param))
    #    sapply(fbtst_p, expectation) / p_t
    #  })

    ############## latent wt
    #wt <- rep(0,n-p)

    #################################################################
    ############################ M STEP #############################
    #################################################################

    ######## innovation parameters
    if(p>1){
      stsum <- apply(st,2,sum) #st[p+1,i]+...+st[n,i], for i=1,...,p.
      #  btstsum <- apply(btst,2,sum) #btst[p+1,i]+...+btst[n,i], for i=1,...,p.
    } else {
      stsum <- sum(st) #st[p+1,i]+...+st[n,i], for i=1,...,p.
      # btstsum <- sum(btst) #btst[p+1,i]+...+btst[n,i], for i=1,...,p.
    }
    ytstsum <- sapply(1:p,function(i) sum(Y[((p+1)-i):(n-i)])-stsum[i])
    #(y[(p+1)-i]-st[p+1,i])+...+(y[n-i]-st[n,i]), for i=1,...,p.

    # lambda
    #lambda.tmp <- (sum((1-wt)*y[(p+1):n])-sum(btstsum))/sum(1-wt)
    lambda.tmp <- (sum(Y[(p+1):n])-sum(stsum))/(n-p)

    # alpha
    if(p==1){
      alpha.tmp <- sum(st)/sum(Y[1:(n-1)])
    } else {
      log_complete_neg <- function(beta) -loglike_complete(stsum,ytstsum,beta)
      EMV <- optim(par=beta,fn=log_complete_neg,method="BFGS")
      beta.tmp <- EMV[[1]]
      alpha.tmp <- as.vector(solve(BETA(beta.tmp))%*%beta.tmp)
    }


    # Test
    if (Iter == 2)
    {
      t2 <- c(alpha, lambda)
    }
    if (Iter == 3)
    {
      t1 <-  c(alpha, lambda)
      t0 <-  c(alpha.tmp, lambda.tmp)

      tp0 <-  (t2-t1)/sum((t1==t2)+((t2-t1)^2)) + (t0-t1)/sum((t1==t0)+((t0-t1)^2))
      tp0 <-  t1 + tp0 / sum((tp0==0) + tp0^2)
    }
    if (Iter > 3)
    {
      t2 <-  t1
      t1 <-  t0
      t0 <-  c(alpha.tmp, lambda.tmp)
      tp1 <-  tp0

      tp0 <-  (t2-t1)/sum((t1==t2)+((t2-t1)^2)) + (t0-t1)/sum((t1==t0)+((t0-t1)^2))
      tp0 <-  t1 + tp0 / sum((tp0==0) + tp0^2)
      Diff <-  sum((tp0-tp1)^2)
    }

    # Update
    alpha <-  alpha.tmp
    lambda <-  lambda.tmp
    param=list()
    param$alpha <- alpha
    param$lambda <- lambda

  }

  Aux <- loglike(Y,p,param)
  lv=Aux$lv

  invisible(list(param=param,lv=lv))

}


###########
# Used function for the loop

fst_propto <- function(y,t,j,param){
  alpha <- param$alpha
  lambda <- param$lambda

  p <- length(alpha)
  yt <- y[t]

  ylast <- y[(t-1):(t-p)]
  top <- min(yt,ylast[j])
  bin <- dsumbin(0:top,ylast[j],alpha[j])

  if(p>1){
    inov <- dprob_trans(yt-0:top,ylast[-j],alpha[-j],lambda)
  } else {inov <- dpois(yt-0:top,lambda)}

  fst <- bin*inov
  return(fst)
}

##########

fbtst_propto <- function(y,t,j,param){
  fbtst <- fst_propto(y,t,j,param)
  return(fbtst)
}

###########
#this function returns the expectation of the non-negative integer r.v. with probability
#function f

expectation <- function(f){
  n <- length(f)-1
  E <- sum(0:n*f)
  return(E)
}

##########
dsumbin <- function(z,n,pr){
  if( any(n<0) ) return(rep(0,length(z)))
  p <- length(n)
  cv <- dbinom(0:n[1],n[1],pr[1]) #density of X1
  if(p>1){
    for(i in 2:p){
      d_bin <- dbinom(0:n[i],n[i],pr[i]) #density of Xi
      cv <- convolution(cv,d_bin,max(z)) #convolution of X1+...+X(i-1) and Xi
    }
  }
  #Let Sn=X1+...+Xn and supp_Sn=n[1]+...+n[p] the support of Sn, then note that
  #cv is now the vector P(Sn=0),...,P(Sn=v), where v=min(supp_Sn,max(z)).
  if(max(z)>sum(n)) cv=c(cv, rep(0,max(z)-sum(n)) )
  #now, cv is P(Sn=0),...,P(Sn=max(z))

  if(any(z<0))
  {
    pos <- which(z<0)
    z[pos] <- 0
    cv <- cv[z+1]
    cv[pos] <- 0
  } else {cv <- cv[z+1]}

  return(cv)
}

#####################################################################
## This function calculates the log-likelihood for an INAR(p) process with parameters a and th

loglike <- function(y,p,param)
{
  n       <- length(y)
  alpha   <- param$alpha
  lambda  <- param$lambda

  if (lambda[length(lambda)]>0){ #it is necessary to avoid wearing messenges in BFGS
    p_t <- sapply((p+1):n,function(t) dprob_trans(y[t],y[(t-1):(t-p)],alpha,lambda))
    lv  <- sum(log(p_t))
  } else {
    lv   <- -1e20
    p_t <-  1
  }

  result <- list()
  result$lv <- lv
  result$p_t <- p_t
  return(result)
}

##

dprob_trans <- function(z,ylast,alpha,lambda){
  if (any(ylast<0)) return(rep(0,length(z)))

  top <- max(z,sum(ylast),0)
  pr1 <- dsumbin(0:top,ylast,alpha)
  pr2 <- dpois(0:top,lambda)
  prob <- convolution(pr1,pr2,max(z,0))

  if(any(z<0))
  {
    pos <- which(z<0)
    z[pos] <- 0
    prob <- prob[z+1]
    prob[pos] <- 0
  } else {
    prob <- prob[z+1]
  }
  return(prob)
}

##

convolution <- function(x,y,top)
{
  prob <- vector() #prob will be the probabilities P(X+Y=0), P(X+Y=1), ...., P(X+Y=top),
  #or P(X+Y=0), P(X+Y=1), ...., P(X+Y=sxy).
  n_x <- length(x); n_y <- length(y); sxy <- length(x)+length(y)-2
  x <- c(x,rep(0,n_y)); y <- c(y,rep(0,n_x))
  TOP <- min(sxy+1,top+1)
  for(i in 1:TOP)
  {
    prob[i] <- sum( x[1:i]*y[i-0:(i-1)] ) #prob[i]=P(X+Y=i-1)
  }
  return(prob)
}

##

loglike_complete=function(stsum,ytstsum,beta)
{
  if(any(beta>=1) || any(beta<0))
  {
    Q=-1e20
  } else {
    A=BETA(beta)
    alpha=solve(A)%*%beta

    Q=sum(stsum*log(alpha))+sum(ytstsum*log(1-alpha))
  }
  return(Q)
}

##

BETA=function(beta)
{
  p=length(beta)
  A=matrix(NA,nrow=p,ncol=p)
  for(i in 1:p)
  {
    A[i,]=rep(beta[i],p)
  }
  diag(A)=1
  return(A)
}




